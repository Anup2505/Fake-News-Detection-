package com.anup.mail;

public class MailConstants {
//	final static public String EMAIL="Your Gmail ID";
//	final static public String PASSWORD="Your Generated Password";
	final static public String EMAIL="anupsingh0912@gmail.com";
	final static public String PASSWORD="ntbe xocq jfzg zyws";
}
